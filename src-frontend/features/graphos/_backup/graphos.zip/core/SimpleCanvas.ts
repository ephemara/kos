/**
 * SimpleCanvas - Enhanced 2D painting canvas with perfect-freehand strokes
 * and Three.js GPU simulations
 */

import * as THREE from 'three';
import getStroke from 'perfect-freehand';

export interface SimpleLayer {
    id: string;
    name: string;
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
    visible: boolean;
    opacity: number;
    // WebGL texture for GPU operations
    texture?: THREE.Texture;
    renderTarget?: THREE.WebGLRenderTarget;
}

export interface SimpleBrush {
    size: number;
    opacity: number;
    hardness: number;
    color: string;
    spacing: number;
    erase: boolean;
    // Symmetry mode
    symmetry: 'OFF' | 'X' | 'Y' | 'RADIAL';
    radialSegments?: number; // For radial symmetry
}

export interface StrokePoint {
    x: number;
    y: number;
    pressure: number;
}

export class SimpleCanvas {
    private mainCanvas: HTMLCanvasElement;
    private mainCtx: CanvasRenderingContext2D;
    private layers: SimpleLayer[] = [];
    private width: number;
    private height: number;
    private viewport: HTMLElement;

    // Transform state
    private _zoom: number = 1.0;
    private _pan = { x: 0, y: 0 };

    // Stroke state
    private isStroking = false;
    private currentStroke: StrokePoint[] = [];
    private currentLayerId: string | null = null;
    private currentBrush: SimpleBrush | null = null;

    // WebGL for GPU simulations
    private renderer: THREE.WebGLRenderer | null = null;
    private simScene: THREE.Scene | null = null;
    private simCamera: THREE.OrthographicCamera | null = null;
    private simQuad: THREE.Mesh | null = null;

    // Resize observer
    private resizeObserver: ResizeObserver | null = null;

    constructor(canvas: HTMLCanvasElement, viewport: HTMLElement, width: number = 2048, height: number = 2048) {
        this.mainCanvas = canvas;
        this.viewport = viewport;
        this.width = width;
        this.height = height;

        // Set canvas size
        canvas.width = width;
        canvas.height = height;
        canvas.style.transformOrigin = '0 0';

        // Get 2D context
        const ctx = canvas.getContext('2d', { alpha: true, willReadFrequently: false });
        if (!ctx) throw new Error('Failed to get 2D context');
        this.mainCtx = ctx;

        // Initial clear
        this.mainCtx.clearRect(0, 0, width, height);

        // Initialize WebGL for simulations
        this.initWebGL();

        // Setup resize observer
        this.resizeObserver = new ResizeObserver(() => this.fitToScreen());
        this.resizeObserver.observe(viewport);

        // Initial fit
        requestAnimationFrame(() => this.fitToScreen());
    }

    private initWebGL(): void {
        try {
            // Create offscreen canvas for WebGL
            const glCanvas = document.createElement('canvas');
            glCanvas.width = this.width;
            glCanvas.height = this.height;

            this.renderer = new THREE.WebGLRenderer({
                canvas: glCanvas,
                alpha: true,
                preserveDrawingBuffer: true,
                antialias: false
            });
            this.renderer.setSize(this.width, this.height);

            this.simScene = new THREE.Scene();
            this.simCamera = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, 0.1, 10);
            this.simCamera.position.z = 1;

            const geometry = new THREE.PlaneGeometry(1, 1);
            this.simQuad = new THREE.Mesh(geometry);
            this.simScene.add(this.simQuad);
        } catch (e) {
            console.warn('WebGL init failed for simulations:', e);
        }
    }

    // ========== TRANSFORM ==========

    get zoom(): number { return this._zoom; }
    get pan() { return this._pan; }

    setTransform(zoom: number, panX: number, panY: number): void {
        this._zoom = Math.max(0.05, Math.min(20, zoom));
        this._pan.x = panX;
        this._pan.y = panY;
        this.mainCanvas.style.transform = `translate(${this._pan.x}px, ${this._pan.y}px) scale(${this._zoom})`;
    }

    fitToScreen(): void {
        const vw = this.viewport.clientWidth;
        const vh = this.viewport.clientHeight;
        if (vw <= 0 || vh <= 0) return;

        const margin = 60;
        const scaleX = (vw - margin) / this.width;
        const scaleY = (vh - margin) / this.height;
        const newZoom = Math.min(scaleX, scaleY, 1.0);

        const scaledW = this.width * newZoom;
        const scaledH = this.height * newZoom;
        const panX = (vw - scaledW) / 2;
        const panY = (vh - scaledH) / 2;

        this.setTransform(newZoom, panX, panY);
    }

    // ========== LAYERS ==========

    addLayer(id: string, name: string, fillColor?: string): SimpleLayer {
        const offscreen = document.createElement('canvas');
        offscreen.width = this.width;
        offscreen.height = this.height;
        const ctx = offscreen.getContext('2d', { alpha: true })!;

        if (fillColor) {
            ctx.fillStyle = fillColor;
            ctx.fillRect(0, 0, this.width, this.height);
        }

        // Create WebGL render target for GPU simulations
        let renderTarget: THREE.WebGLRenderTarget | undefined;
        if (this.renderer) {
            renderTarget = new THREE.WebGLRenderTarget(this.width, this.height, {
                minFilter: THREE.LinearFilter,
                magFilter: THREE.LinearFilter,
                format: THREE.RGBAFormat
            });
        }

        const layer: SimpleLayer = {
            id,
            name,
            canvas: offscreen,
            ctx,
            visible: true,
            opacity: 1.0,
            renderTarget
        };

        this.layers.push(layer);
        this.compose();
        return layer;
    }

    deleteLayer(id: string): void {
        const idx = this.layers.findIndex(l => l.id === id);
        if (idx !== -1) {
            const layer = this.layers[idx];
            layer.renderTarget?.dispose();
            this.layers.splice(idx, 1);
            this.compose();
        }
    }

    getLayer(id: string): SimpleLayer | undefined {
        return this.layers.find(l => l.id === id);
    }

    getLayers(): SimpleLayer[] {
        return this.layers;
    }

    // ========== COMPOSITING ==========

    compose(): void {
        this.mainCtx.clearRect(0, 0, this.width, this.height);
        this.drawCheckerboard();

        for (const layer of this.layers) {
            if (!layer.visible) continue;
            this.mainCtx.globalAlpha = layer.opacity;
            this.mainCtx.drawImage(layer.canvas, 0, 0);
        }
        this.mainCtx.globalAlpha = 1.0;
    }

    private drawCheckerboard(): void {
        const size = 20;
        const lightColor = '#2a2a2a';
        const darkColor = '#222222';

        for (let y = 0; y < this.height; y += size) {
            for (let x = 0; x < this.width; x += size) {
                const isLight = ((x / size) + (y / size)) % 2 === 0;
                this.mainCtx.fillStyle = isLight ? lightColor : darkColor;
                this.mainCtx.fillRect(x, y, size, size);
            }
        }
    }

    // ========== PAINTING with perfect-freehand ==========

    startStroke(): void {
        this.isStroking = true;
        this.currentStroke = [];
    }

    continueStroke(u: number, v: number, pressure: number, brush: SimpleBrush, layerId: string): void {
        if (!this.isStroking) return;

        const layer = this.getLayer(layerId);
        if (!layer || !layer.visible) return;

        // Store brush and layer for endStroke
        this.currentBrush = brush;
        this.currentLayerId = layerId;

        // Convert UV to pixel coordinates
        const x = u * this.width;
        const y = (1 - v) * this.height;

        // Add point to current stroke
        this.currentStroke.push({ x, y, pressure });

        // Render the stroke incrementally for immediate feedback
        this.renderStrokePreview(layer, brush);
    }

    private renderStrokePreview(layer: SimpleLayer, brush: SimpleBrush): void {
        if (this.currentStroke.length < 2) return;

        const ctx = layer.ctx;

        // Generate all symmetry versions of the stroke
        const strokes = this.generateSymmetricStrokes(this.currentStroke, brush);

        for (const stroke of strokes) {
            // Use perfect-freehand for smooth stroke outline
            const points = stroke.map(p => [p.x, p.y, p.pressure]);

            const outlinePoints = getStroke(points, {
                size: brush.size,
                thinning: 0.5,
                smoothing: 0.5,
                streamline: 0.5,
                easing: (t: number) => t,
                start: { cap: true, taper: 0, easing: (t: number) => t },
                end: { cap: true, taper: 0, easing: (t: number) => t }
            });

            if (outlinePoints.length === 0) continue;

            // Draw filled stroke
            ctx.save();

            if (brush.erase) {
                ctx.globalCompositeOperation = 'destination-out';
            } else {
                ctx.globalCompositeOperation = 'source-over';
            }

            ctx.globalAlpha = brush.opacity;
            ctx.fillStyle = brush.color;

            ctx.beginPath();
            const [firstX, firstY] = outlinePoints[0];
            ctx.moveTo(firstX, firstY);

            for (let i = 1; i < outlinePoints.length; i++) {
                const [px, py] = outlinePoints[i];
                ctx.lineTo(px, py);
            }

            ctx.closePath();
            ctx.fill();
            ctx.restore();
        }

        this.compose();
    }

    private generateSymmetricStrokes(stroke: StrokePoint[], brush: SimpleBrush): StrokePoint[][] {
        const strokes: StrokePoint[][] = [stroke];
        const centerX = this.width / 2;
        const centerY = this.height / 2;

        if (brush.symmetry === 'X' || brush.symmetry === 'RADIAL') {
            // Mirror across X axis (vertical symmetry)
            const mirrored = stroke.map(p => ({
                x: this.width - p.x,
                y: p.y,
                pressure: p.pressure
            }));
            strokes.push(mirrored);
        }

        if (brush.symmetry === 'Y' || brush.symmetry === 'RADIAL') {
            // Mirror across Y axis (horizontal symmetry)
            const mirrored = stroke.map(p => ({
                x: p.x,
                y: this.height - p.y,
                pressure: p.pressure
            }));
            strokes.push(mirrored);
        }

        if (brush.symmetry === 'RADIAL') {
            // Add diagonal mirror (both axes)
            const diagonal = stroke.map(p => ({
                x: this.width - p.x,
                y: this.height - p.y,
                pressure: p.pressure
            }));
            strokes.push(diagonal);

            // Add more radial segments if specified
            const segments = brush.radialSegments || 8;
            if (segments > 4) {
                for (let i = 1; i < segments / 2; i++) {
                    const angle = (Math.PI * 2 * i) / segments;
                    const cos = Math.cos(angle);
                    const sin = Math.sin(angle);

                    const rotated = stroke.map(p => {
                        const dx = p.x - centerX;
                        const dy = p.y - centerY;
                        return {
                            x: centerX + dx * cos - dy * sin,
                            y: centerY + dx * sin + dy * cos,
                            pressure: p.pressure
                        };
                    });
                    strokes.push(rotated);

                    // Also add the X-mirrored version
                    const rotatedMirrored = rotated.map(p => ({
                        x: this.width - p.x,
                        y: p.y,
                        pressure: p.pressure
                    }));
                    strokes.push(rotatedMirrored);
                }
            }
        }

        return strokes;
    }

    endStroke(layerId?: string): void {
        this.isStroking = false;
        this.currentStroke = [];
        this.currentBrush = null;
        this.currentLayerId = null;
    }

    // ========== GPU SIMULATIONS ==========

    applySimulation(layerId: string, shaderMaterial: THREE.ShaderMaterial): void {
        if (!this.renderer || !this.simScene || !this.simCamera || !this.simQuad) {
            console.warn('WebGL not available for simulations');
            return;
        }

        const layer = this.getLayer(layerId);
        if (!layer) return;

        // Create texture from layer canvas
        const inputTexture = new THREE.CanvasTexture(layer.canvas);
        inputTexture.minFilter = THREE.LinearFilter;
        inputTexture.magFilter = THREE.LinearFilter;

        // Set input texture in shader
        if (shaderMaterial.uniforms.tInput) {
            shaderMaterial.uniforms.tInput.value = inputTexture;
        }
        if (shaderMaterial.uniforms.uResolution) {
            shaderMaterial.uniforms.uResolution.value.set(this.width, this.height);
        }

        this.simQuad.material = shaderMaterial;

        // Create render target
        const renderTarget = new THREE.WebGLRenderTarget(this.width, this.height, {
            minFilter: THREE.LinearFilter,
            magFilter: THREE.LinearFilter,
            format: THREE.RGBAFormat
        });

        // Render to target
        this.renderer.setRenderTarget(renderTarget);
        this.renderer.render(this.simScene, this.simCamera);
        this.renderer.setRenderTarget(null);

        // Read pixels back to layer canvas
        const pixels = new Uint8Array(this.width * this.height * 4);
        this.renderer.readRenderTargetPixels(renderTarget, 0, 0, this.width, this.height, pixels);

        // Create ImageData and put it on the layer
        const imageData = new ImageData(new Uint8ClampedArray(pixels), this.width, this.height);

        // Flip Y (WebGL is bottom-up, Canvas is top-down)
        const flippedData = this.flipImageDataY(imageData);
        layer.ctx.putImageData(flippedData, 0, 0);

        // Cleanup
        inputTexture.dispose();
        renderTarget.dispose();

        this.compose();
    }

    private flipImageDataY(imageData: ImageData): ImageData {
        const { width, height, data } = imageData;
        const flipped = new Uint8ClampedArray(data.length);
        const rowSize = width * 4;

        for (let y = 0; y < height; y++) {
            const srcRow = y * rowSize;
            const dstRow = (height - 1 - y) * rowSize;
            for (let x = 0; x < rowSize; x++) {
                flipped[dstRow + x] = data[srcRow + x];
            }
        }

        return new ImageData(flipped, width, height);
    }

    // ========== UTILITIES ==========

    clear(layerId: string): void {
        const layer = this.getLayer(layerId);
        if (layer) {
            layer.ctx.clearRect(0, 0, this.width, this.height);
            this.compose();
        }
    }

    fill(layerId: string, color: string): void {
        const layer = this.getLayer(layerId);
        if (layer) {
            layer.ctx.fillStyle = color;
            layer.ctx.fillRect(0, 0, this.width, this.height);
            this.compose();
        }
    }

    resize(newWidth: number, newHeight: number): void {
        this.width = newWidth;
        this.height = newHeight;
        this.mainCanvas.width = newWidth;
        this.mainCanvas.height = newHeight;

        for (const layer of this.layers) {
            const imageData = layer.ctx.getImageData(0, 0, layer.canvas.width, layer.canvas.height);
            layer.canvas.width = newWidth;
            layer.canvas.height = newHeight;
            layer.ctx.putImageData(imageData, 0, 0);
        }

        if (this.renderer) {
            this.renderer.setSize(newWidth, newHeight);
        }

        this.compose();
        this.fitToScreen();
    }

    exportImage(callback: (blob: Blob) => void, type: 'PNG' | 'JPEG' = 'PNG'): void {
        const exportCanvas = document.createElement('canvas');
        exportCanvas.width = this.width;
        exportCanvas.height = this.height;
        const ctx = exportCanvas.getContext('2d')!;

        for (const layer of this.layers) {
            if (!layer.visible) continue;
            ctx.globalAlpha = layer.opacity;
            ctx.drawImage(layer.canvas, 0, 0);
        }

        exportCanvas.toBlob(
            (blob) => { if (blob) callback(blob); },
            type === 'PNG' ? 'image/png' : 'image/jpeg',
            0.95
        );
    }

    dispose(): void {
        if (this.resizeObserver) {
            this.resizeObserver.disconnect();
        }
        for (const layer of this.layers) {
            layer.renderTarget?.dispose();
        }
        this.renderer?.dispose();
        this.layers = [];
    }

    // ========== GETTERS ==========

    getWidth(): number { return this.width; }
    getHeight(): number { return this.height; }
    getCanvas(): HTMLCanvasElement { return this.mainCanvas; }
    getRenderer(): THREE.WebGLRenderer | null { return this.renderer; }
}
