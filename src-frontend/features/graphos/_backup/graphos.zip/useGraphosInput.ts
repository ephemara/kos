
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useGesture } from '@use-gesture/react';

export const useGraphosInput = (
    canvasRef: React.RefObject<HTMLCanvasElement>,
    viewportRef: React.RefObject<HTMLDivElement>,
    engineRef: React.MutableRefObject<any>,
    targetZoomRef: React.MutableRefObject<number>,
    targetPanRef: React.MutableRefObject<THREE.Vector2>,
    zoomWorldPointRef: React.MutableRefObject<THREE.Vector2 | null>,
    zoomScreenPointRef: React.MutableRefObject<THREE.Vector2 | null>,
    onSpaceChange: (isHeld: boolean) => void,
    brush: any,
    activeLayerId: string | null
) => {
    const isSpaceHeld = useRef(false);
    const isOrbiting = useRef(false);

    // Keyboard State (Space / Alt)
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (document.activeElement?.matches('input, textarea')) return;

            // Spacebar -> Pan Mode
            if (e.code === 'Space' && !e.repeat) {
                e.preventDefault();
                isSpaceHeld.current = true;
                onSpaceChange(true);
                if (canvasRef.current) canvasRef.current.style.cursor = 'grab';
            }
            // Alt -> Orbit Mode (3D)
            if (e.key === 'Alt') {
                isOrbiting.current = true;
                if (canvasRef.current) canvasRef.current.style.cursor = 'move';
            }
        };

        const handleKeyUp = (e: KeyboardEvent) => {
            if (e.code === 'Space') {
                isSpaceHeld.current = false;
                onSpaceChange(false);
                if (canvasRef.current) canvasRef.current.style.cursor = 'crosshair';
            }
            if (e.key === 'Alt') {
                isOrbiting.current = false;
                if (canvasRef.current) canvasRef.current.style.cursor = 'crosshair';
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, [onSpaceChange]);

    // Gesture Handling
    useGesture({
        onDrag: ({ delta: [dx, dy], event, buttons, first, last, pinching, cancel }) => {
            if (pinching) return cancel();
            const r = engineRef.current;
            if (!r) return;

            const isPanAction = isSpaceHeld.current || buttons === 4 || (buttons === 1 && isSpaceHeld.current);
            const isPaintAction = buttons === 1 && !isSpaceHeld.current && !isOrbiting.current;

            // PANNING
            if (isPanAction) {
                if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';

                if (!r.is3D) {
                    // Update Pan
                    r.pan.x += dx;
                    r.pan.y += dy;
                    targetPanRef.current.x = r.pan.x;
                    targetPanRef.current.y = r.pan.y;

                    // Direct set for immediate responsiveness
                    r.setTransform(r.zoom, r.pan);
                }
                return;
            }

            // PAINTING
            if (isPaintAction) {
                if (first) {
                    if (r.startStroke) r.startStroke();
                }

                // Normalize event coordinates to UV
                if (event instanceof PointerEvent) {
                    const canvas = canvasRef.current;
                    if (canvas) {
                        const rect = canvas.getBoundingClientRect();
                        const localX = event.clientX - rect.left;
                        const localY = event.clientY - rect.top;
                        const u = localX / rect.width;
                        const v = 1.0 - (localY / rect.height);
                        const pressure = event.pressure || 0.5;

                        // Bounds check lazy (allow slight overdraw for edge strokes)
                        if (u >= -0.2 && u <= 1.2 && v >= -0.2 && v <= 1.2) {
                            if (r.continueStroke) r.continueStroke(new THREE.Vector2(u, v), pressure, brush, activeLayerId);
                        }
                    }
                }

                if (last) {
                    if (r.endStroke) r.endStroke(activeLayerId);
                }
            }
        },

        onWheel: ({ delta: [dx, dy], event }) => {
            event.preventDefault();
            const r = engineRef.current;
            if (!r || r.is3D) return;

            const viewport = viewportRef.current;
            if (!viewport) return;
            const rect = viewport.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const offsetX = (event as any).clientX - centerX;
            const offsetY = (event as any).clientY - centerY;

            const currentWorldX = (offsetX - r.pan.x) / r.zoom;
            const currentWorldY = (offsetY - r.pan.y) / r.zoom;

            const zoomSpeed = 0.0015;
            let scaleFactor = 1.0 - (dy * zoomSpeed);
            scaleFactor = Math.max(0.5, Math.min(1.5, scaleFactor));

            const newTargetZoom = Math.max(0.01, Math.min(50.0, targetZoomRef.current * scaleFactor));
            targetZoomRef.current = newTargetZoom;

            const newTargetPanX = offsetX - currentWorldX * newTargetZoom;
            const newTargetPanY = offsetY - currentWorldY * newTargetZoom;

            targetPanRef.current.x = newTargetPanX;
            targetPanRef.current.y = newTargetPanY;
        },

        onPinch: ({ offset: [d, a], event, first, cancel }) => {
            // Basic pinch placeholder, usually handled via onWheel or specialized pinch logic
            // For now we rely on Wheel for zoom
        }
    }, {
        target: viewportRef,
        eventOptions: { passive: false },
        drag: { filterTaps: true },
        pinch: { scaleBounds: { min: 0.1, max: 10 } }
    });

    // Helper for painting
    const paintAtEvent = (e: PointerEvent, r: any) => {
        const canvas = canvasRef.current;
        if (!canvas || !r.handlePaint) return;
        const rect = canvas.getBoundingClientRect();
        const localX = e.clientX - rect.left;
        const localY = e.clientY - rect.top;
        const u = localX / rect.width;
        const v = 1.0 - (localY / rect.height);

        if (u >= -0.5 && u <= 1.5 && v >= -0.5 && v <= 1.5) {
            const pressure = e.pressure || 1.0;
            r.handlePaint(new THREE.Vector2(u, v), pressure);
        }
    };

    return {};
};
