
import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { Activity, Scaling, Move, Box, Stamp, CircuitBoard, Aperture, Package, Palette, Layers } from 'lucide-react';
import { initGraphosEngine } from './KGraphosEngine';
import KGraphosCursor from './KGraphosCursor';
import KGraphosBrushMenu from './KGraphosBrushMenu';
import KGraphosSpaceMenu from './KGraphosSpaceMenu';
import KGraphosLayerMenu from './KGraphosLayerMenu';
import { FloatingMaterialPicker } from '@/ui/materials';
import AlphaMenu from '@/ui/widgets/AlphaMenu';
import { useGraphosInput } from './useGraphosInput';
import { useRegisterQuickMenuCommands } from '@/ui/shell/quickMenuRegistry';
import { GRAPHOS_SIMS } from './KGraphosSpaceMenu';
// AppShell integration
import { AppShell } from '@/ui/shell/AppShell';
import { AppMenuBar } from '@/ui/shell/AppMenuBar';
import { DockPanel } from '@/ui/shell/DockPanel';
import TopBar from './ui/TopBar';
import LeftPanel from './ui/LeftPanel';
import RightPanel from './ui/RightPanel';


const lerp = (start: number, end: number, t: number) => start * (1 - t) + end * t;

export default function KGraphos({ sharedState, onCommit, onAlphaCommit, onMaterialCommit, ...props }: any) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const viewportRef = useRef<HTMLDivElement>(null);
    const engineRef = useRef<any>(null);

    const [isEngineReady, setIsEngineReady] = useState(false);
    const [activeTab, setActiveTab] = useState('layers');
    const [activeLayerId, setActiveLayerId] = useState<string | null>(null);
    const [layers, setLayers] = useState<any[]>([]);
    const [isHoveringCanvas, setIsHoveringCanvas] = useState(false);
    const [isHoveringViewport, setIsHoveringViewport] = useState(false); // Track viewport (canvas area) hover
    const [isSpaceHeld, setIsSpaceHeld] = useState(false); // Space key state for cursor visibility
    const [canvasConfig, setCanvasConfig] = useState({ width: 2048, height: 2048 });
    const [gpuMode, setGpuMode] = useState(true);
    const [is3DMode, setIs3DMode] = useState(false);

    const targetZoom = useRef(1.0);
    const currentZoom = useRef(1.0);
    const targetPan = useRef(new THREE.Vector2(0, 0));
    const zoomWorldPoint = useRef<THREE.Vector2 | null>(null); // World point to keep under cursor during zoom
    const zoomScreenPoint = useRef<THREE.Vector2 | null>(null); // Screen point of cursor during zoom
    const isZooming = useRef(false); // Track if zoom animation is active
    const [displayZoom, setDisplayZoom] = useState(1.0);

    const [materialMode, setMaterialMode] = useState(false);
    const [activeMaterial, setActiveMaterial] = useState<any>(null);
    const [materialChannels, setMaterialChannels] = useState({
        albedo: true,
        normal: false,
        roughness: false,
        metalness: false,
        emission: false
    });

    const DEFAULT_BRUSHES = [
        { id: 'INK', label: 'INK', icon: 'PenTool', hardness: 1.0, flow: 1.0, opacity: 1.0 },
        { id: 'SOFT', label: 'SOFT', icon: 'Brush', hardness: 0.0, flow: 0.5, opacity: 0.8 },
        { id: 'CHISEL', label: 'CHISEL', icon: 'Square', hardness: 1.0, flow: 0.8, opacity: 1.0 },
        { id: 'SKETCH', label: 'SKETCH', icon: 'Highlighter', hardness: 0.5, flow: 0.2, opacity: 0.6 },
        { id: 'WASH', label: 'WASH', icon: 'Droplet', hardness: 0.2, flow: 0.1, opacity: 0.4 },
        { id: 'ERASE', label: 'ERASE', icon: 'Eraser', hardness: 0.8, flow: 1.0, opacity: 1.0 },
        { id: 'SCATTER', label: 'CHAOS', icon: 'Shuffle', hardness: 0.5, flow: 0.5, opacity: 0.8 },
        { id: 'FILL', label: 'FILL', icon: 'PaintBucket', hardness: 1.0, flow: 1.0, opacity: 1.0 }
    ];

    const [savedBrushes, setSavedBrushes] = useState(DEFAULT_BRUSHES);

    const handleBrushCommit = (newBrush: any) => {
        setSavedBrushes(prev => [...prev, newBrush]);
    };

    const [brush, setBrush] = useState({
        size: 50,
        opacity: 1.0,
        flow: 1.0, // Deprecated, kept for compatibility but hidden
        hardness: 0.5,
        color: '#000000',
        alphaMap: null,
        isSeamless: false,
        spacing: 0.1,
        erase: false,
        tool: 'INK',
        angle: 0.0,
        // HYPER EDITION PARAMS
        jitterPos: 0.0,
        jitterSize: 0.0,
        jitterAngle: 0.0,
        jitterHue: 0.0,
        symmetry: 'NONE' // NONE, X, Y, RADIAL
    });

    const [showBrushMenuState, setShowBrushMenuState] = useState({ show: false, x: 0, y: 0 });
    const [showSpaceMenuState, setShowSpaceMenuState] = useState({ show: false, x: 0, y: 0 });
    const [showLayerMenuState, setShowLayerMenuState] = useState({ show: false, x: 0, y: 0 });
    const [showAlphaMenuState, setShowAlphaMenuState] = useState({ show: false, x: 0, y: 0 });
    const [showMaterialMenuState, setShowMaterialMenuState] = useState({ show: false, x: 0, y: 0 });

    // SIMULATION STATE
    const [activeSims, setActiveSims] = useState<Record<string, boolean>>({
        drip: false, bleed: false, liquify: false, gravity: false, rivulet: false, growth: false,
        wind: false, magnetic: false, datamosh: false, nebula: false, thermal: false, sort: false, life: false,
        vortex: false, erosion: false
    });

    const graphosQuickMenuCommands = React.useMemo(
        () =>
            GRAPHOS_SIMS.map((s) => ({
                id: `graphos:sim:${s.id}`,
                label: `Toggle ${s.label}`,
                description: s.desc,
                icon: s.icon,
                keywords: ['graphos', 'sim', s.id, s.label],
                category: 'K-GRAPHOS / Sims',
                action: () =>
                    setActiveSims((prev) => ({
                        ...prev,
                        [s.id]: !prev[s.id],
                    })),
            })),
        []
    );

    useRegisterQuickMenuCommands('kgraphos', graphosQuickMenuCommands as any);

    const [simParams, setSimParams] = useState({
        speed: 1.0,
        chaos: 0.5,
        decay: 0.95,
        scale: 1.0
    });

    const simStateRef = useRef({ activeSims, simParams, activeLayerId, gpuMode });
    useEffect(() => { simStateRef.current = { activeSims, simParams, activeLayerId, gpuMode }; }, [activeSims, simParams, activeLayerId, gpuMode]);

    useEffect(() => {
        if (activeMaterial) {
            const loader = new THREE.TextureLoader();
            const load = (url: string) => new Promise<THREE.Texture | null>(r => { if (!url) r(null); else loader.load(url, (t) => { t.colorSpace = THREE.SRGBColorSpace; r(t); }); });
            // Use canonical baked maps (new KMaterialAsset schema) with back-compat
            const maps = activeMaterial.baked?.maps || {};
            const baseColor = maps.baseColor || activeMaterial.base || '';
            const normal = maps.normal || activeMaterial.normal || '';
            const roughness = maps.roughness || activeMaterial.roughness || '';
            const metallic = maps.metallic || activeMaterial.metallic || '';
            const emissive = maps.emissive || activeMaterial.emissive || '';
            Promise.all([load(baseColor), load(normal), load(roughness), load(metallic), load(emissive)]).then(([alb, nrm, rgh, met, ems]) => {
                if (nrm) nrm.colorSpace = THREE.LinearSRGBColorSpace;
                if (rgh) rgh.colorSpace = THREE.LinearSRGBColorSpace;
                if (met) met.colorSpace = THREE.LinearSRGBColorSpace;
                if (engineRef.current) engineRef.current.loadedTextures = { albedo: alb, normal: nrm, roughness: rgh, metalness: met, emission: ems };
            });
        } else if (engineRef.current) { engineRef.current.loadedTextures = null; }
    }, [activeMaterial]);

    useEffect(() => {
        if (!canvasRef.current || !viewportRef.current) return;
        // Guard against React Strict Mode double-init (canvas can only have one WebGL context)
        if (engineRef.current) return;

        const engine = initGraphosEngine(canvasRef.current, viewportRef.current, canvasConfig);
        engineRef.current = engine;
        const id = `layer_bg_${Date.now()}`;
        engine.addLayer(id, 'Background', [1, 1, 1, 1]);
        setLayers([{ id, name: 'Background', visible: true, opacity: 1.0, keyframes: [], transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0 } }]);
        setActiveLayerId(id);
        setIsEngineReady(true);
        setTimeout(() => { if (engineRef.current) { engineRef.current.fitToScreen(); targetZoom.current = engineRef.current.zoom; currentZoom.current = engineRef.current.zoom; engineRef.current.render(); } }, 100);

        let frameId: number;

        const animate = () => {
            frameId = requestAnimationFrame(animate);
            const r = engineRef.current;
            const state = simStateRef.current;
            if (r) {
                if (!r.is3D) {
                    const diffZoom = targetZoom.current - currentZoom.current;
                    const diffPanX = targetPan.current.x - r.pan.x;
                    const diffPanY = targetPan.current.y - r.pan.y;

                    if (Math.abs(diffZoom) > 0.0001 || Math.abs(diffPanX) > 0.1 || Math.abs(diffPanY) > 0.1) {
                        isZooming.current = true;
                        currentZoom.current = lerp(currentZoom.current, targetZoom.current, 0.15);
                        r.pan.x = lerp(r.pan.x, targetPan.current.x, 0.15);
                        r.pan.y = lerp(r.pan.y, targetPan.current.y, 0.15);

                        r.setTransform(currentZoom.current, r.pan);

                        // Update display zoom every frame for smooth cursor scaling
                        setDisplayZoom(currentZoom.current);

                        // Clear zoom tracking when animation completes
                        if (Math.abs(diffZoom) < 0.001 && Math.abs(diffPanX) < 0.1 && Math.abs(diffPanY) < 0.1) {
                            zoomWorldPoint.current = null;
                            zoomScreenPoint.current = null;
                            isZooming.current = false;
                        }
                    } else {
                        isZooming.current = false;
                    }
                } else { if (r.controls) r.controls.update(); }

                if (state.gpuMode && state.activeLayerId) {
                    const layer = r.getLayer(state.activeLayerId);
                    if (layer) {
                        let needsUpdate = false;
                        // CORE
                        if (state.activeSims.drip) { r.runSim(state.activeLayerId, 'DRIP', state.simParams); needsUpdate = true; }
                        if (state.activeSims.bleed) { r.runSim(state.activeLayerId, 'BLEED', state.simParams); needsUpdate = true; }
                        // Run Liquify if active OR if in Material Mode (for viscous fluid feel)
                        if (state.activeSims.liquify || materialMode) { r.runSim(state.activeLayerId, 'LIQUIFY', state.simParams); needsUpdate = true; }
                        if (state.activeSims.rivulet) { r.runSim(state.activeLayerId, 'RIVULET', state.simParams); needsUpdate = true; }
                        if (state.activeSims.growth) { r.runSim(state.activeLayerId, 'GROWTH', state.simParams); needsUpdate = true; }

                        // ADVANCED
                        if (state.activeSims.wind) { r.runSim(state.activeLayerId, 'WIND', state.simParams); needsUpdate = true; }
                        if (state.activeSims.magnetic) { r.runSim(state.activeLayerId, 'MAGNETIC', state.simParams); needsUpdate = true; }
                        if (state.activeSims.datamosh) { r.runSim(state.activeLayerId, 'DATAMOSH', state.simParams); needsUpdate = true; }
                        if (state.activeSims.nebula) { r.runSim(state.activeLayerId, 'NEBULA', state.simParams); needsUpdate = true; }
                        if (state.activeSims.thermal) { r.runSim(state.activeLayerId, 'THERMAL', state.simParams); needsUpdate = true; }
                        if (state.activeSims.sort) { r.runSim(state.activeLayerId, 'SORT', state.simParams); needsUpdate = true; }
                        if (state.activeSims.life) { r.runSim(state.activeLayerId, 'LIFE', state.simParams); needsUpdate = true; }
                        if (state.activeSims.vortex) { r.runSim(state.activeLayerId, 'VORTEX', state.simParams); needsUpdate = true; }

                        if (needsUpdate) r.needsUpdate = true;
                    }
                }

                // Compose if needed (throttled to frame rate)
                if (r.needsUpdate) {
                    r.compose();
                    r.needsUpdate = false;
                }

                r.render();
            }
        };
        animate();

        const handleResize = () => { if (engineRef.current) { engineRef.current.fitToScreen(); targetZoom.current = engineRef.current.zoom; } };
        window.addEventListener('resize', handleResize);
        return () => { cancelAnimationFrame(frameId); window.removeEventListener('resize', handleResize); if (engine) engine.dispose(); engineRef.current = null; };
    }, []);

    const handleCanvasResize = (size: number) => {
        if (engineRef.current) { engineRef.current.resize(size, size); setCanvasConfig({ width: size, height: size }); }
    };

    // Playback logic removed

    useEffect(() => {
        if (engineRef.current) {
            engineRef.current.handlePaint = (uv: THREE.Vector2, pressure: number) => {
                const r = engineRef.current;
                const layerId = activeLayerId;
                if (!r || !layerId) return;
                const layer = r.getLayer(layerId);
                if (!layer || !layer.visible) return;

                // Initialize lastPaintPos if null
                if (!r.lastPaintPos) r.lastPaintPos = uv.clone();

                // Calculate Distance & Steps
                const dist = uv.distanceTo(r.lastPaintPos);
                const brushSizeUV = brush.size / canvasConfig.width; // Approx UV size
                const spacingUV = Math.max(0.0001, brushSizeUV * brush.spacing);

                const steps = Math.ceil(dist / spacingUV);

                // Interpolate Points
                const interpolatedPoints: THREE.Vector2[] = [];
                for (let i = 1; i <= steps; i++) {
                    const t = i / steps;
                    interpolatedPoints.push(new THREE.Vector2().lerpVectors(r.lastPaintPos, uv, t));
                }
                // If no movement (click), paint at least once
                if (steps === 0) interpolatedPoints.push(uv.clone());

                // Update Velocity for Sims
                let delta = new THREE.Vector2(0, 0);
                delta.subVectors(uv, r.lastPaintPos).multiplyScalar(50.0);
                r.currentVelocity = delta;

                // Apply velocity if Liquify is active OR if in Material Mode (for viscous feel)
                if (gpuMode && (activeSims.liquify || materialMode)) {
                    r.paintEngine.splatVelocity(layer, uv, delta, brush.size * pressure);
                }

                r.lastPaintPos = uv.clone();

                // Process Each Interpolated Point
                interpolatedPoints.forEach(pointUV => {
                    const points = [{ uv: pointUV, size: brush.size, angle: 0, color: brush.color }];

                    // 1. Jitter
                    if (brush.jitterPos > 0 || brush.jitterSize > 0 || brush.jitterAngle > 0 || brush.jitterHue > 0) {
                        const p = points[0];
                        if (brush.jitterPos > 0) { p.uv.x += (Math.random() - 0.5) * 0.1 * brush.jitterPos; p.uv.y += (Math.random() - 0.5) * 0.1 * brush.jitterPos; }
                        if (brush.jitterSize > 0) { p.size *= (1.0 + (Math.random() - 0.5) * brush.jitterSize); }
                        if (brush.jitterAngle > 0) { p.angle += (Math.random() - 0.5) * Math.PI * brush.jitterAngle; }
                    }

                    // 2. Symmetry
                    if (brush.symmetry === 'X') points.push({ ...points[0], uv: new THREE.Vector2(1.0 - points[0].uv.x, points[0].uv.y) });
                    else if (brush.symmetry === 'Y') points.push({ ...points[0], uv: new THREE.Vector2(points[0].uv.x, 1.0 - points[0].uv.y) });
                    else if (brush.symmetry === 'RADIAL') {
                        const count = 6;
                        const center = new THREE.Vector2(0.5, 0.5);
                        const baseUV = points[0].uv.clone().sub(center);
                        for (let i = 1; i < count; i++) {
                            const angle = (Math.PI * 2 * i) / count;
                            const rotated = new THREE.Vector2(
                                baseUV.x * Math.cos(angle) - baseUV.y * Math.sin(angle),
                                baseUV.x * Math.sin(angle) + baseUV.y * Math.cos(angle)
                            ).add(center);
                            points.push({ ...points[0], uv: rotated });
                        }
                    }

                    const channels = materialMode
                        ? materialChannels
                        : { albedo: true, normal: false, roughness: false, metalness: false, emission: false };

                    points.forEach(p => {
                        const dynamicBrush = { ...brush, size: p.size, color: p.color, flow: 1.0 }; // Force Flow 1.0
                        if (brush.erase) dynamicBrush.opacity = 1.0; // Eraser usually needs full strength or handled via opacity
                        r.paintEngine.paint(p.uv, dynamicBrush, layer, channels, r.quadMesh, materialMode ? r.loadedTextures : null);
                    });
                });

                // Flag for composition in next frame
                r.needsUpdate = true;
            };
        }
    }, [brush, activeLayerId, gpuMode, activeSims, materialMode, materialChannels, canvasConfig]);

    useGraphosInput(
        canvasRef,
        viewportRef,
        engineRef,
        targetZoom,
        targetPan,
        zoomWorldPoint,
        zoomScreenPoint,
        setIsSpaceHeld,
        brush,
        activeLayerId
    );

    const handleLayerAdd = useCallback(() => {
        if (!engineRef.current || !isEngineReady) return;
        const id = `layer_${Date.now()}`;
        engineRef.current.addLayer(id, `Layer ${layers.length + 1}`, [0, 0, 0, 0]);
        setLayers(prev => [...prev, {
            id,
            name: `Layer ${prev.length + 1}`,
            visible: true,
            opacity: 1.0,
            keyframes: [],
            transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0 }
        }]);
        setActiveLayerId(id);
    }, [isEngineReady, layers.length]);

    // Keyframe Management
    // Keyframe logic removed

    const handleLayerDelete = useCallback((id: string) => {
        if (!engineRef.current) return;
        engineRef.current.deleteLayer(id);
        setLayers(prev => {
            const next = prev.filter(l => l.id !== id);
            if (activeLayerId === id) setActiveLayerId(next.length > 0 ? next[next.length - 1].id : null);
            return next;
        });
    }, [activeLayerId]);

    const handleLayerVisibility = useCallback((id: string, solo: boolean) => {
        if (!engineRef.current) return;
        if (solo) {
            setLayers(prev => prev.map(l => {
                const isTarget = l.id === id;
                const engineLayer = engineRef.current.getLayer(l.id);
                if (engineLayer) engineLayer.visible = isTarget;
                return { ...l, visible: isTarget };
            }));
        } else {
            const layer = engineRef.current.getLayer(id);
            if (layer) {
                layer.visible = !layer.visible;
                setLayers(prev => prev.map(l => l.id === id ? { ...l, visible: layer.visible } : l));
            }
        }
        engineRef.current.compose();
    }, []);

    const handleLayerOpacity = useCallback((id: string, opacity: number) => {
        if (!engineRef.current) return;
        const layer = engineRef.current.getLayer(id);
        if (layer) {
            layer.opacity = opacity;
            setLayers(prev => prev.map(l => l.id === id ? { ...l, opacity } : l));
            engineRef.current.compose();
        }
    }, []);

    const handleExport = (type: 'PNG' | 'JPEG' | 'ALPHA' | 'SAMPLE') => {
        if (!engineRef.current) return;
        engineRef.current.exportImage((blob: Blob) => {
            if (type === 'ALPHA' && onAlphaCommit) {
                onAlphaCommit({ name: `Graphos_Alpha_${Date.now()}`, url: URL.createObjectURL(blob) });
            } else if (type === 'SAMPLE') {
                // Send to K-Sample (AutoPBR)
                const url = URL.createObjectURL(blob);
                if ((props as any).setTempImage) (props as any).setTempImage(url);
                if ((props as any).switchModule) (props as any).switchModule('autopbr');
            } else {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = `Graphos_${Date.now()}.${type === 'JPEG' ? 'jpg' : 'png'}`; a.click();
            }
        }, type === 'JPEG' ? 'JPEG' : 'PNG');
    };

    // 3D toggle removed

    const [lockedMenus, setLockedMenus] = useState<Set<string>>(new Set());

    const toggleMenuLock = (menuId: string) => {
        setLockedMenus(prev => {
            const next = new Set(prev);
            if (next.has(menuId)) next.delete(menuId);
            else next.add(menuId);
            return next;
        });
    };

    // CONTEXT MENU HANDLER
    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        setShowBrushMenuState(prev => ({ show: !prev.show, x: e.clientX, y: e.clientY }));

        // Don't close others if they are locked
        if (!lockedMenus.has('alpha')) setShowAlphaMenuState(prev => ({ ...prev, show: false }));
        if (!lockedMenus.has('space')) setShowSpaceMenuState(prev => ({ ...prev, show: false }));
        if (!lockedMenus.has('material')) setShowMaterialMenuState(prev => ({ ...prev, show: false }));
    };

    // HOTKEY HANDLERS
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (document.activeElement?.matches('input, textarea')) return;

            // 'B' = Brush Menu
            if (e.key === 'b' || e.key === 'B') {
                e.preventDefault();
                const rect = canvasRef.current?.getBoundingClientRect();
                if (rect) {
                    setShowBrushMenuState({ show: !showBrushMenuState.show, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }
            }

            // 'L' = Layer Menu
            if (e.key === 'l' || e.key === 'L') {
                e.preventDefault();
                const rect = canvasRef.current?.getBoundingClientRect();
                if (rect) {
                    setShowLayerMenuState({ show: !showLayerMenuState.show, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }
            }

            // 'M' = Material Menu
            if (e.key === 'm' || e.key === 'M') {
                e.preventDefault();
                const rect = canvasRef.current?.getBoundingClientRect();
                if (rect) {
                    setShowMaterialMenuState({ show: !showMaterialMenuState.show, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }
            }

            // 'A' = Alpha Menu
            if (e.key === 'a' || e.key === 'A') {
                e.preventDefault();
                const rect = canvasRef.current?.getBoundingClientRect();
                if (rect) {
                    setShowAlphaMenuState({ show: !showAlphaMenuState.show, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }
            }

            // Space Menu Hotkeys (Q)
            if (e.key.toLowerCase() === 'q') {
                if (lockedMenus.has('space')) return;
                const rect = canvasRef.current?.getBoundingClientRect();
                if (rect) {
                    setShowSpaceMenuState(prev => ({ show: !prev.show, x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }));
                }
            }

            // Layer Navigation (Arrow Up/Down)
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                setLayers(prev => {
                    const idx = prev.findIndex(l => l.id === activeLayerId);
                    if (idx < prev.length - 1) {
                        const nextId = prev[idx + 1].id;
                        setActiveLayerId(nextId);
                    }
                    return prev;
                });
            }
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setLayers(prev => {
                    const idx = prev.findIndex(l => l.id === activeLayerId);
                    if (idx > 0) {
                        const nextId = prev[idx - 1].id;
                        setActiveLayerId(nextId);
                    }
                    return prev;
                });
            }

            // W Key: Toggle Active Simulation
            if (e.key.toLowerCase() === 'w') {
                const activeKeys = Object.keys(activeSims).filter(k => activeSims[k]);
                if (activeKeys.length > 0) {
                    const nextSims = { ...activeSims };
                    activeKeys.forEach(k => nextSims[k] = false);
                    setActiveSims(nextSims);
                } else {
                    setActiveSims(prev => ({ ...prev, wind: true }));
                }
            }

            // Legacy handlers removed - using new key handlers above
            if (e.key.toLowerCase() === 's') { if (activeLayerId) { handleLayerVisibility(activeLayerId, true); engineRef.current.compose(); } }

            // F Key: Fit/Frame Canvas
            if (e.key.toLowerCase() === 'f') {
                if (engineRef.current) {
                    engineRef.current.fitToScreen();
                    targetZoom.current = engineRef.current.zoom;
                    currentZoom.current = engineRef.current.zoom;
                    targetPan.current.set(engineRef.current.pan.x, engineRef.current.pan.y);
                    zoomWorldPoint.current = null;
                    zoomScreenPoint.current = null;
                }
            }
        };

        const trackMouse = (e: MouseEvent) => { (window as any).lastMouseX = e.clientX; (window as any).lastMouseY = e.clientY; };
        window.addEventListener('mousemove', trackMouse); window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [activeLayerId, layers, handleLayerVisibility, showSpaceMenuState.show, showBrushMenuState.show, showAlphaMenuState.show, activeSims, lockedMenus, showLayerMenuState.show, showMaterialMenuState.show]);




    return (
        <div
            className="w-full h-full flex flex-col bg-[#000] overflow-hidden"
            style={{ userSelect: 'none', touchAction: 'none', position: 'relative' }}
        >
            <KGraphosCursor brush={brush} zoomRef={currentZoom} viewportRef={viewportRef} show={(isHoveringViewport || isZooming.current) && !is3DMode && !isSpaceHeld} />

            {/* RADIAL MENUS */}
            <KGraphosBrushMenu
                visible={showBrushMenuState.show}
                position={{ x: showBrushMenuState.x, y: showBrushMenuState.y }}
                brush={brush}
                setBrush={setBrush}
                brushes={savedBrushes}
                onSelect={() => setShowBrushMenuState({ ...showBrushMenuState, show: false })}
                isLocked={lockedMenus.has('brush')}
                onToggleLock={() => toggleMenuLock('brush')}
            />
            <AlphaMenu
                visible={showAlphaMenuState.show}
                position={{ x: showAlphaMenuState.x, y: showAlphaMenuState.y }}
                alphas={sharedState?.alphas || []}
                activeAlpha={brush.alphaMap}
                onSelect={(alpha: any) => {
                    if (!alpha) {
                        setBrush(prev => ({ ...prev, alphaMap: null }));
                    } else {
                        const loader = new THREE.TextureLoader();
                        loader.load(alpha.url, (tex) => {
                            setBrush(prev => ({ ...prev, alphaMap: tex }));
                        });
                    }
                    setShowAlphaMenuState({ ...showAlphaMenuState, show: false });
                }}
            />
            <KGraphosSpaceMenu
                visible={showSpaceMenuState.show}
                position={{ x: showSpaceMenuState.x, y: showSpaceMenuState.y }}
                activeSims={activeSims}
                toggleSim={(id: string) => setActiveSims(prev => {
                    return { ...prev, [id]: !prev[id] };
                })}
                simParams={simParams}
                setSimParams={setSimParams}
                onReset={() => { if (activeLayerId && engineRef.current) { const l = engineRef.current.getLayer(activeLayerId); if (l) engineRef.current.paintEngine.clearLayer(l); engineRef.current.compose(); } }}
                gpuMode={gpuMode}
                setGpuMode={setGpuMode}
                isLocked={lockedMenus.has('space')}
                onToggleLock={() => toggleMenuLock('space')}
            />

            <KGraphosLayerMenu
                visible={showLayerMenuState.show}
                position={{ x: showLayerMenuState.x, y: showLayerMenuState.y }}
                layers={layers}
                activeLayerId={activeLayerId}
                setActiveLayerId={setActiveLayerId}
                onAdd={handleLayerAdd}
                onDelete={handleLayerDelete}
                onToggleVisibility={handleLayerVisibility}
                onOpacityChange={handleLayerOpacity}
                onSelect={() => setShowLayerMenuState({ ...showLayerMenuState, show: false })}
            />

            <FloatingMaterialPicker
                visible={showMaterialMenuState.show}
                position={{ x: showMaterialMenuState.x, y: showMaterialMenuState.y }}
                materials={sharedState?.materials || []}
                activeMaterial={activeMaterial}
                onSelect={setActiveMaterial}
                onMaterialMode={setMaterialMode}
                onClose={() => setShowMaterialMenuState({ ...showMaterialMenuState, show: false })}
                accentColor="rose"
            />

            <AppShell
                menuBar={<AppMenuBar menus={[
                    {
                        label: 'File', items: [
                            { label: 'New Canvas', onSelect: () => { } },
                            { label: 'Export PNG', onSelect: () => handleExport('PNG') },
                            { label: 'Export JPEG', onSelect: () => handleExport('JPEG') },
                            { label: 'Commit as Alpha', onSelect: () => handleExport('ALPHA') },
                        ]
                    },
                    {
                        label: 'Edit', items: [
                            { label: 'Undo', onSelect: () => { } },
                            { label: 'Redo', onSelect: () => { } },
                            { label: 'Clear Layer', onSelect: () => { if (activeLayerId && engineRef.current) { const l = engineRef.current.getLayer(activeLayerId); if (l) engineRef.current.paintEngine.clearLayer(l); engineRef.current.compose(); } } },
                        ]
                    },
                    {
                        label: 'View', items: [
                            { label: 'Fit Canvas', onSelect: () => { if (engineRef.current) { engineRef.current.fitToScreen(); targetZoom.current = engineRef.current.zoom; currentZoom.current = engineRef.current.zoom; } } },
                        ]
                    },
                ]} />}
                topBar={
                    <TopBar
                        brush={brush}
                        setBrush={setBrush}
                        gpuMode={gpuMode}
                        setGpuMode={setGpuMode}
                        canvasConfig={canvasConfig}
                        onResize={handleCanvasResize}
                    />
                }
                left={{
                    tabs: [
                        {
                            id: 'alpha', label: 'Alpha', icon: Stamp, content: (
                                <LeftPanel tab="alpha" alphas={sharedState?.alphas || []} onAlphaCommit={onAlphaCommit} brush={brush} setBrush={setBrush} onBrushCommit={handleBrushCommit} engineRef={engineRef} activeLayerId={activeLayerId} handleExport={handleExport} />
                            )
                        },
                        {
                            id: 'gen', label: 'Gen', icon: CircuitBoard, content: (
                                <LeftPanel tab="gen" alphas={sharedState?.alphas || []} onAlphaCommit={onAlphaCommit} brush={brush} setBrush={setBrush} onBrushCommit={handleBrushCommit} engineRef={engineRef} activeLayerId={activeLayerId} handleExport={handleExport} />
                            )
                        },
                        {
                            id: 'filter', label: 'Filter', icon: Aperture, content: (
                                <LeftPanel tab="filter" alphas={sharedState?.alphas || []} onAlphaCommit={onAlphaCommit} brush={brush} setBrush={setBrush} onBrushCommit={handleBrushCommit} engineRef={engineRef} activeLayerId={activeLayerId} handleExport={handleExport} />
                            )
                        },
                        {
                            id: 'export', label: 'Export', icon: Package, content: (
                                <LeftPanel tab="export" alphas={sharedState?.alphas || []} onAlphaCommit={onAlphaCommit} brush={brush} setBrush={setBrush} onBrushCommit={handleBrushCommit} engineRef={engineRef} activeLayerId={activeLayerId} handleExport={handleExport} />
                            )
                        },
                    ],
                }}
                right={{
                    tabs: [
                        {
                            id: 'color', label: 'Color', icon: Palette, content: (
                                <RightPanel tab="color" brush={brush} setBrush={setBrush} projectMaterials={sharedState?.materials || []} activeMaterial={activeMaterial} setActiveMaterial={setActiveMaterial} materialMode={materialMode} setMaterialMode={setMaterialMode} materialChannels={materialChannels} setMaterialChannels={setMaterialChannels} engineRef={engineRef} onMaterialCommit={onMaterialCommit} layers={layers} activeLayerId={activeLayerId} setActiveLayerId={setActiveLayerId} onLayerAdd={handleLayerAdd} onLayerDelete={handleLayerDelete} onLayerVisibility={handleLayerVisibility} onLayerOpacity={handleLayerOpacity} />
                            )
                        },
                        {
                            id: 'materials', label: 'PBR', icon: Box, content: (
                                <RightPanel tab="materials" brush={brush} setBrush={setBrush} projectMaterials={sharedState?.materials || []} activeMaterial={activeMaterial} setActiveMaterial={setActiveMaterial} materialMode={materialMode} setMaterialMode={setMaterialMode} materialChannels={materialChannels} setMaterialChannels={setMaterialChannels} engineRef={engineRef} onMaterialCommit={onMaterialCommit} layers={layers} activeLayerId={activeLayerId} setActiveLayerId={setActiveLayerId} onLayerAdd={handleLayerAdd} onLayerDelete={handleLayerDelete} onLayerVisibility={handleLayerVisibility} onLayerOpacity={handleLayerOpacity} />
                            )
                        },
                        {
                            id: 'layers', label: 'Layers', icon: Layers, content: (
                                <RightPanel tab="layers" brush={brush} setBrush={setBrush} projectMaterials={sharedState?.materials || []} activeMaterial={activeMaterial} setActiveMaterial={setActiveMaterial} materialMode={materialMode} setMaterialMode={setMaterialMode} materialChannels={materialChannels} setMaterialChannels={setMaterialChannels} engineRef={engineRef} onMaterialCommit={onMaterialCommit} layers={layers} activeLayerId={activeLayerId} setActiveLayerId={setActiveLayerId} onLayerAdd={handleLayerAdd} onLayerDelete={handleLayerDelete} onLayerVisibility={handleLayerVisibility} onLayerOpacity={handleLayerOpacity} />
                            )
                        },
                    ],
                }}
            >
                {/* VIEWPORT */}
                <div className="h-full w-full flex flex-col overflow-hidden" style={{ minWidth: 0 }}>
                    <div
                        ref={viewportRef}
                        className={`flex-1 relative overflow-hidden bg-[#080808] ${isHoveringViewport ? 'cursor-none' : ''}`}
                        style={{ touchAction: 'none', minHeight: 0 }}
                        onPointerEnter={() => setIsHoveringViewport(true)}
                        onPointerLeave={() => setIsHoveringViewport(false)}
                    >
                        <canvas
                            ref={canvasRef}
                            className="absolute block touch-none"
                        />
                    </div>
                    <div className="h-8 shrink-0 bg-[#0a0a0a] border-t border-[#222] flex items-center justify-between px-4 text-[9px] z-10">
                        <div className="flex items-center gap-4 text-gray-500 font-bold"><span className="flex items-center gap-2"><Scaling size={10} /> {(displayZoom * 100)?.toFixed(0)}%</span><span className="flex items-center gap-2"><Move size={10} /> {engineRef.current?.pan?.x.toFixed(0) || 0}, {engineRef.current?.pan?.y.toFixed(0) || 0}</span></div>
                        <div className="flex items-center gap-2 text-rose-500 font-bold">{gpuMode ? <Activity size={10} className="animate-pulse" /> : <div className="w-2 h-2 rounded-full bg-gray-700" />}{gpuMode ? "PHYSICS KERNEL ACTIVE" : "STANDARD RENDERER"}</div>
                    </div>
                </div>
            </AppShell>
        </div>
    );
}
