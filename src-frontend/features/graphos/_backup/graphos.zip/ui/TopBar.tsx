import React from 'react';
import * as Toolbar from '@/ui/primitives/Toolbar';
import { ColorPopover } from '@/ui/primitives/ColorPopover';
import { Brush, Eraser, Cpu, Box, Monitor, Split, Circle } from 'lucide-react';
import { cn } from '@/ui/primitives/cn';


interface TopBarProps {
    brush: any;
    setBrush: (v: any) => void;
    gpuMode: boolean;
    setGpuMode: (v: boolean) => void;
    canvasConfig: { width: number; height: number };
    onResize: (size: number) => void;
}

export default function TopBar({
    brush, setBrush,
    gpuMode, setGpuMode,
    canvasConfig, onResize
}: TopBarProps) {
    return (
        <Toolbar.Root className="border-b border-rose-900/30 bg-gradient-to-r from-[#0a0a0a] to-[#111]">
            {/* LEFT: TOOLS */}
            <Toolbar.Group>
                <Toolbar.ToggleGroup
                    type="single"
                    value={brush.erase ? 'erase' : 'brush'}
                    onValueChange={(v) => v && setBrush((b: any) => ({ ...b, erase: v === 'erase' }))}
                >
                    <Toolbar.ToggleItem value="brush" tooltip="Brush Tool (B)" className="data-[state=on]:bg-rose-600 data-[state=on]:text-white data-[state=on]:shadow-lg data-[state=on]:shadow-rose-900/50">
                        <Brush size={14} />
                    </Toolbar.ToggleItem>
                    <Toolbar.ToggleItem value="erase" tooltip="Eraser Tool (E)" className="data-[state=on]:bg-rose-600 data-[state=on]:text-white data-[state=on]:shadow-lg data-[state=on]:shadow-rose-900/50">
                        <Eraser size={14} />
                    </Toolbar.ToggleItem>
                </Toolbar.ToggleGroup>

                <Toolbar.Separator />

                {/* SLIDERS (Manual Implementation for now) */}
                <div className="flex items-center gap-3 px-1">
                    <div className="flex flex-col w-20 gap-0.5 group">
                        <div className="flex justify-between text-[9px] font-bold text-gray-500 uppercase group-hover:text-rose-400 transition-colors">
                            <span>Size</span>
                            <span className="text-rose-400">{brush.size}px</span>
                        </div>
                        <input
                            type="range" min="1" max="500" step="1"
                            value={brush.size}
                            onChange={(e) => setBrush((b: any) => ({ ...b, size: parseFloat(e.target.value) }))}
                            className="w-full h-1 bg-[#222] rounded-lg appearance-none cursor-pointer accent-rose-500 hover:accent-rose-400"
                        />
                    </div>
                    <div className="flex flex-col w-16 gap-0.5 group">
                        <div className="flex justify-between text-[9px] font-bold text-gray-500 uppercase group-hover:text-rose-400 transition-colors">
                            <span>Opacity</span>
                            <span className="text-rose-400">{(brush.opacity * 100).toFixed(0)}%</span>
                        </div>
                        <input
                            type="range" min="0.0" max="1.0" step="0.01"
                            value={brush.opacity}
                            onChange={(e) => setBrush((b: any) => ({ ...b, opacity: parseFloat(e.target.value) }))}
                            className="w-full h-1 bg-[#222] rounded-lg appearance-none cursor-pointer accent-rose-500 hover:accent-rose-400"
                        />
                    </div>
                </div>

                <Toolbar.Separator />

                {/* SYMMETRY */}
                <Toolbar.ToggleGroup
                    type="single"
                    value={brush.symmetry}
                    onValueChange={(v) => v && setBrush((b: any) => ({ ...b, symmetry: v }))}
                >
                    <Toolbar.ToggleItem value="NONE" tooltip="No Symmetry">OFF</Toolbar.ToggleItem>
                    <Toolbar.ToggleItem value="X" tooltip="X Symmetry">X</Toolbar.ToggleItem>
                    <Toolbar.ToggleItem value="Y" tooltip="Y Symmetry">Y</Toolbar.ToggleItem>
                    <Toolbar.ToggleItem value="RADIAL" tooltip="Radial Symmetry (Slow)">
                        <Split size={12} />
                    </Toolbar.ToggleItem>
                </Toolbar.ToggleGroup>
            </Toolbar.Group>

            {/* CENTER: COLOR */}
            <div className="absolute left-1/2 -translate-x-1/2">
                <ColorPopover
                    color={brush.color}
                    onChange={(c) => setBrush((b: any) => ({ ...b, color: c }))}
                    label="PIGMENT"
                />
            </div>

            {/* RIGHT: MODE */}
            <Toolbar.Group>

                <Toolbar.Button
                    active={gpuMode}
                    onClick={() => setGpuMode(!gpuMode)}
                    tooltip="GPU Acceleration"
                    className={gpuMode ? "bg-cyan-900/20 text-cyan-400 border border-cyan-500 shadow-[0_0_10px_rgba(34,211,238,0.3)] hover:bg-cyan-900/40" : ""}
                >
                    <Cpu size={14} />
                    <span className="ml-1">GPU</span>
                </Toolbar.Button>

                <Toolbar.Separator />

                <div className="flex items-center gap-2">
                    <Monitor size={14} className="text-gray-500" />
                    <select
                        value={canvasConfig.width}
                        onChange={(e) => onResize(parseInt(e.target.value))}
                        className="bg-transparent text-[10px] font-bold text-gray-300 outline-none cursor-pointer hover:text-white"
                    >
                        <option value={1024}>1024x1024</option>
                        <option value={2048}>2048x2048</option>
                        <option value={4096}>4096x4096</option>
                    </select>
                </div>

            </Toolbar.Group>
        </Toolbar.Root>
    );
}
